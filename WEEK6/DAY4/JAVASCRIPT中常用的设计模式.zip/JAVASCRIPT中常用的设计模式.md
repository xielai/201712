##JAVASCRIPT中常用的设计模式
@(201712)

###学习各种设计模式有什么作用？
> [ 开发 ]
> 开发效率高
> 利于团队协作
>  
> [ 维护 ]
> 有利于代码的升级改版
> 逻辑清晰，代码严谨，利于后期的维护
>  
> [ 通用 ]
> 我们依托设计模式可以实现组件化、模块化、插件化、框架化以及一些常用类库方法的编写
>  
> `技术语言发展路线`
> 语言语法更新迭代之路（路漫漫而其修远兮）
> 语法初步稳定阶段 -> 研究核心语法和使用的早一批人 ->封装各种类库和插件 ->大量研究核心的开发人员...  ->出现各种设计模式 ->框架(VUE、REACT)

###插件、组件、类库、框架的区别
> 类库：提供一些真实项目开发中常用的方法（方法做了完善处理：兼容处理、细节优化），方便我们开发和维护 [ jQuery、Zepto... ]
>  
> 插件：把项目中某一部分进行插件封装（是具备具体的业务逻辑的，更加有针对性），以后再有类似的需求，直接导入插件即可，相关业务逻辑代码不需要自己在编写了 [ jquery.drag.js 、jquery.dialog.js、jquery.validate.min.js 、datepicker日历插件、echarts统计图插件、iscroll插件...]
>  
> 组件：类似于插件，但是插件一般只是把JS部分封装，组件不仅封装了JS部分，而且把CSS部分也封装了，以后再使用的时候，我们直接的按照文档使用说明引入CSS/JS，搭建对应的结构，什么都不用做功能自然就有了 [ swiper组件、bootstrap组件... ]
>  
> 框架：比上面的三个都要庞大，它不仅仅提供了很多常用的方法、而且也可以支持一些插件的扩展（可以把一些插件集成到框架中运行）、更重要的是提供了非常优秀的代码管理设计思想...  [ REACT、VUE、ANGULAR、REACT NATIVE... ]

###JS中常用的设计模式
> 单例设计模式、构造原型设计模式、发布订阅设计模式、promise设计模式...

`单例设计模式`
```javascript
//=>单例模式：把实现当前这个模块所有的属性和方法汇总到同一个命名空间下（分组作用，避免了全局变量的污染）
let exampleRender=(function(){
	//=>实现当前模块具体业务逻辑的方法全部存放在闭包中
	let fn=function(){
		//...
	}

	return {
		init:function(){
			//=>入口方法：控制当前模块具体的业务逻辑顺序
			fn();
		}
	}
})();
exampleRender.init();
```
> 真实项目中，我们如果想要实现具体的业务逻辑需求，都可以依托于单例模式构建；我们把项目划分成各大板块或者模块，把实现同一个板块的方法放在一个独立的命名空间下，方便团队协作开发；

`构造原型模式：最贴近OOP面向对象编程思想的`
> 以后真实项目中，不管是封装类库还是插件或者UI组件，基本上都是基于构造原型模式来开发的
```javascript
class Tool{
	constructor(){
		this.isCompatible='addEventListener' in document;//=>如果不兼容返回FALSE(IE6~8)
		
	}
	//=>挂载到原型上的方法
	css(){
		//...
	}
	//=>挂载到普通对象上的方法
	static distinct(){
		//...
	}
}

class Banner extends Tool{
	constructor(...arg){
		super();
		this.xxx=xxx;
	}
	//=>挂载到子类原型上的方法
	bindData(){
		this.css();//=>把父类原型上的方法执行（子类继承了父类，那么子类的实例就可以调取父类原型上的方法了）
		this.distinct===undefined;//=>子类的实例只能调取父类原型上的方法，以及父类给实例提供的私有属性方法，但是父类做为普通对象加入的静态方法，子类的实例是无法调取的 (只有这样才可以调取使用：Tool.distinct())
	}
}
```
> 我有三个类 A/B/C ，我想让C继承A和B
```javascript
class A{
	...
}
class B extends A{
	...
}
class C extends B{
	...
}
```

`发布订阅设计模式：观察者模式`
> 不同于单例和构造，发布订阅是小型设计模式，应用到某一个具体的需求中：凡是当到达某个条件之后要执行N多方法，我们都可以依托于发布订阅设计模式管理和规划我们的JS代码
>  
> 我们经常把发布订阅设计模式嵌套到其它的设计模式中

`promise设计模式`
> 解决AJAX异步请求层级嵌套的问题
> 
> 它也是小型设计模式，目的是为了解决层级嵌套问题的，我们也会经常把它嵌套在其它的设计模式中运行
```javascript
$.ajax({
	url:'/A',
	async:true,//=>异步
	success:function(result){
		$.ajax({
			url:'/B',
			async:true,
			success:function(){
				//=>还会有后续嵌套
			}
		});		
	}
});
```

###发布订阅设计模式
> 俗称叫做“观察者模式”
>  
> 实现思路和原理：
> 1、我们先创建一个计划表（容器）
> 2、后期需要做什么事情，我们都依次把需要处理的事情增加到计划表中
> 3、当符合某个条件的时候，我们只需要通知计划表中的方法按照顺序依次执行即可

`JQ中的发布订阅`
> JQ中提供了实现发布订阅设计模式的方法
```javascript
let $plan = $.Callbacks();//=>创建一个计划表

let fn = function(n,m){
	//=>n=100 m=200
}
$plan.add(fn);//=>向计划表中增加方法
$plan.remove(fn);//=>从计划表中移除方法

$plan.fire(100，200);//=>通知计划表中所有的方法按照顺序执行；100 200会分别作为实参传递给每一个需要执行的方法；
```

`封装一个类似于JQ的发布订阅模式库`
> 我们自己基于ES6封装一个发布订阅模式库
>  
> 1、基于构造函数封装
> 2、模拟JQ的操作步骤
> 3、注意数组塌陷问题
> 4、封装EACH遍历数组中的每一项
```javascript
~function () {
    //=>EACH:遍历数组中每一项的内容
    let each = function (ary, callBack) {
        for (let i = 0; i < ary.length; i++) {
            let result = callBack && callBack(ary[i], i);

            //=>如果回调函数中返回FALSE,代表结束当前正在遍历的操作(仿照JQ中的EACH语法实现的)
            if (result === false) break;

            //=>如果回调函数中返回的是DEL,代表当前这一项在回调函数中被删除了,为了防止数组塌陷问题,我们让索引减减
            if (result === 'DEL') i--;
        }
    };

    class Plan {
        constructor() {
            this.planList = [];//=>存放方法的容器
        }

        //=>挂载到PLAN原型上的方法
        add(fn) {
            let planList = this.planList,
                flag = true;
            //=>去重处理
            each(planList, function (item, index) {
                if (item === fn) flag = false;
                return flag;
            });
            flag ? planList.push(fn) : null;
        }

        remove(fn) {
            let planList = this.planList;
            each(planList, function (item, index) {
                if (item === fn) {
                    //planList.splice(index, 1);
                    //=>这样会引起数组塌陷(详情见图)

                    planList[index] = null;
                    //=>这样处理位置存在(索引在),但是值没有了
                    return false;
                }
            });
        }

        fire(...arg) {
            let planList = this.planList;
            each(planList, function (item, index) {
                if (item === null) {
                    //=>当前项是已经被REMOVE移除掉的
                    planList.splice(index, 1);
                    return 'DEL';
                }
                item(...arg);
            });
        }

        //=>挂载到PLAN对象上的属性和方法
        static Callbacks() {
            return new Plan();
        }
    }

    window.$ = window.Plan = Plan;
}();
```
![Alt text](./1512201623407.png)

